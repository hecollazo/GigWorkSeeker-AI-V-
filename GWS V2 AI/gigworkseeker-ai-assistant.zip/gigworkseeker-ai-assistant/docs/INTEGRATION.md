# GigWorkSeeker AI Assistant - Integration Guide

## Overview

The AI Assistant is a conversational interface powered by Claude that helps users navigate the GigWorkSeeker platform. It can find gigs, recommend service providers, explain platform features, and assist with natural language task posting.

---

## Files Included

| File | Purpose | Platform |
|------|---------|----------|
| `GigWorkSeekerAI.jsx` | React component for web/desktop | Web |
| `AIAssistantFragment.kt` | Kotlin/Compose fragment for mobile | Android |

---

## Web Integration (React)

### 1. Install Dependencies

```bash
npm install lucide-react
```

### 2. Add the Component

Copy `GigWorkSeekerAI.jsx` to your components directory:

```
src/
  components/
    ai/
      GigWorkSeekerAI.jsx
```

### 3. Import and Use

```jsx
import GigWorkSeekerAI from './components/ai/GigWorkSeekerAI';

// In your app or route
function App() {
  return (
    <div>
      <GigWorkSeekerAI />
    </div>
  );
}
```

### 4. Add Navigation Entry

Add a route for the AI Assistant:

```jsx
// In your router configuration
<Route path="/assistant" element={<GigWorkSeekerAI />} />
```

### 5. Add Navigation Link

```jsx
<Link to="/assistant">
  <Sparkles size={20} />
  AI Assistant
</Link>
```

---

## Android Integration (Kotlin/Compose)

### 1. Add Dependencies

In your `app/build.gradle`:

```kotlin
dependencies {
    // Compose
    implementation("androidx.compose.material3:material3:1.2.0")
    implementation("androidx.compose.material:material-icons-extended:1.6.0")
    
    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0")
    
    // Hilt for DI
    implementation("com.google.dagger:hilt-android:2.48")
    kapt("com.google.dagger:hilt-compiler:2.48")
}
```

### 2. Add the Fragment

Copy `AIAssistantFragment.kt` to your UI package:

```
app/src/main/java/com/gigworkseeker/app/
  ui/
    ai/
      AIAssistantFragment.kt
```

### 3. Add Navigation

In your navigation graph (`nav_graph.xml`):

```xml
<fragment
    android:id="@+id/aiAssistantFragment"
    android:name="com.gigworkseeker.app.ui.ai.AIAssistantFragment"
    android:label="AI Assistant" />
```

### 4. Add Bottom Navigation Item

```xml
<item
    android:id="@+id/nav_ai_assistant"
    android:icon="@drawable/ic_assistant"
    android:title="AI Assistant" />
```

### 5. Handle Navigation

```kotlin
bottomNav.setOnItemSelectedListener { item ->
    when (item.itemId) {
        R.id.nav_ai_assistant -> {
            navController.navigate(R.id.aiAssistantFragment)
            true
        }
        // ... other items
    }
}
```

---

## API Configuration

The AI Assistant uses Claude's API. The API key is handled automatically in the Claude.ai environment. For standalone deployment:

### Web (Environment Variable)

```env
VITE_ANTHROPIC_API_KEY=your_api_key_here
```

Update the fetch call:

```jsx
headers: {
  'Content-Type': 'application/json',
  'x-api-key': import.meta.env.VITE_ANTHROPIC_API_KEY,
  'anthropic-version': '2023-06-01'
}
```

### Android (Secrets/BuildConfig)

In `local.properties`:
```
ANTHROPIC_API_KEY=your_api_key_here
```

In `build.gradle`:
```kotlin
buildTypes {
    release {
        buildConfigField("String", "ANTHROPIC_API_KEY", "\"${project.findProperty('ANTHROPIC_API_KEY')}\"")
    }
}
```

Update the request:
```kotlin
.addHeader("x-api-key", BuildConfig.ANTHROPIC_API_KEY)
```

---

## Features

### What the AI Assistant Can Do

| Feature | Description |
|---------|-------------|
| **Find Gigs** | Search for gigs by location, skill, pay rate, duration |
| **Provider Recommendations** | Find top-rated service providers for specific tasks |
| **Platform Guidance** | Explain escrow, disputes, verification, payments |
| **Natural Language Posting** | Create gig posts from conversational descriptions |
| **Smart Suggestions** | Context-aware follow-up suggestions after each response |
| **GIG Token Info** | Answer questions about the platform's cryptocurrency |

### Conversation Context

The system prompt includes comprehensive platform knowledge:
- User types (Customers vs Service Providers)
- Verification requirements
- Payment options (SOL, GIG, fiat)
- Escrow mechanics
- Dispute resolution process
- All gig categories

---

## Customization

### Adding New Suggestion Categories

In the `generateSuggestions` function, add new keyword patterns:

```jsx
if (lowerUser.includes('token') || lowerUser.includes('gig token')) {
  return [
    { icon: '💎', text: 'What is the GIG token?' },
    { icon: '📈', text: 'How do I earn tokens?' },
    { icon: '🔒', text: 'Staking rewards' }
  ];
}
```

### Modifying the System Prompt

Update the `systemPrompt` constant to add new platform features or change the assistant's behavior.

### Styling

- **Web**: Modify the `styles` object in `GigWorkSeekerAI.jsx`
- **Android**: Update `GWSColors` object and component modifiers in `AIAssistantFragment.kt`

---

## Future Enhancements

Potential additions for the AI Assistant:

1. **Voice Input** - Speech-to-text for hands-free interaction
2. **Rich Responses** - Inline gig cards, provider profiles, maps
3. **Action Execution** - Direct gig posting, provider booking from chat
4. **Conversation History** - Persist chats across sessions
5. **Proactive Suggestions** - Notifications based on user behavior
6. **Multi-language Support** - Localized responses

---

## Troubleshooting

### Web
- **CORS errors**: Ensure the API proxy is configured correctly
- **Blank responses**: Check browser console for API errors
- **Styling issues**: Verify font imports are loading

### Android
- **Network errors**: Add `INTERNET` permission to manifest
- **Compose issues**: Ensure Compose version compatibility
- **Hilt errors**: Verify `@HiltAndroidApp` on Application class

---

## Support

For questions about integration, reach out to:
- **Email**: support@gigworkseeker.com
- **Discord**: [GigWorkSeeker Community](https://discord.gg/gigworkseeker)
