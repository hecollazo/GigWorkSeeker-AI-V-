# GigWorkSeeker AI Assistant - API Documentation

## Overview

The AI Assistant uses Claude's Messages API to generate contextual responses. This document covers the API integration details.

---

## Claude API Integration

### Endpoint

```
POST https://api.anthropic.com/v1/messages
```

### Headers

| Header | Value | Required |
|--------|-------|----------|
| `Content-Type` | `application/json` | Yes |
| `anthropic-version` | `2023-06-01` | Yes |
| `x-api-key` | Your API key | Standalone only |

> **Note**: When running inside Claude.ai artifacts, authentication is handled automatically.

### Request Body

```json
{
  "model": "claude-sonnet-4-20250514",
  "max_tokens": 1000,
  "system": "<system_prompt>",
  "messages": [
    {
      "role": "user",
      "content": "Find gigs near me"
    }
  ]
}
```

### Response

```json
{
  "id": "msg_01XYZ...",
  "type": "message",
  "role": "assistant",
  "content": [
    {
      "type": "text",
      "text": "I can help you find gigs in your area! What type of work are you looking for?"
    }
  ],
  "model": "claude-sonnet-4-20250514",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 150,
    "output_tokens": 45
  }
}
```

---

## System Prompt Structure

The system prompt provides Claude with complete platform context:

```javascript
const systemPrompt = `
You are the GigWorkSeeker AI Assistant...

PLATFORM OVERVIEW:
[Platform description]

KEY FEATURES:
- GIG Token: [details]
- Smart Contract Escrow: [details]
- Zero-Knowledge Proof Verification: [details]
- GPS-Based Matching: [details]
- 5-Star Rating System: [details]
- Dispute Resolution: [details]

USER TYPES:
- Customers: [details]
- Service Providers: [details]

VERIFICATION REQUIREMENTS:
[Requirements list]

PAYMENT OPTIONS:
[Payment methods]

YOUR ROLE:
[Assistant responsibilities]

RESPONSE STYLE:
[Communication guidelines]

CATEGORIES AVAILABLE:
[All gig categories]
`;
```

---

## Conversation History

The assistant maintains conversation context by sending the full message history:

```javascript
const messages = [
  { role: "user", content: "What gigs are available?" },
  { role: "assistant", content: "There are several categories..." },
  { role: "user", content: "Show me delivery gigs" }
];
```

### Web Implementation

```javascript
const conversationHistory = messages
  .filter(m => !m.suggestions)
  .map(m => ({
    role: m.role,
    content: m.content
  }));
```

### Android Implementation

```kotlin
val conversationHistory = messages.value
    .filter { it.suggestions == null || it.role == MessageRole.ASSISTANT }
    .map { ClaudeMessage(
        role = if (it.role == MessageRole.USER) "user" else "assistant",
        content = it.content
    ) }
```

---

## Error Handling

### Common Error Codes

| Code | Description | Action |
|------|-------------|--------|
| 400 | Bad Request | Check request format |
| 401 | Unauthorized | Verify API key |
| 429 | Rate Limited | Implement backoff |
| 500 | Server Error | Retry with delay |

### Web Error Handling

```javascript
try {
  const response = await fetch(url, options);
  
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  
  const data = await response.json();
  return data.content[0].text;
  
} catch (error) {
  console.error('API Error:', error);
  return "I'm having trouble connecting. Please try again.";
}
```

### Android Error Handling

```kotlin
try {
    val response = httpClient.newCall(request).execute()
    
    if (!response.isSuccessful) {
        throw IOException("HTTP ${response.code}")
    }
    
    val body = response.body?.string() ?: throw IOException("Empty response")
    return json.decodeFromString<ClaudeResponse>(body)
    
} catch (e: Exception) {
    Log.e("AIAssistant", "API Error", e)
    throw e
}
```

---

## Rate Limiting

Claude API has rate limits based on your plan:

| Plan | Requests/min | Tokens/min |
|------|--------------|------------|
| Free | 5 | 20,000 |
| Build | 50 | 40,000 |
| Scale | 1,000 | 400,000 |

### Implementing Backoff

```javascript
async function callWithRetry(fn, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (error.status === 429 && i < maxRetries - 1) {
        const delay = Math.pow(2, i) * 1000;
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
      throw error;
    }
  }
}
```

---

## Streaming (Optional)

For longer responses, streaming provides better UX:

```javascript
const response = await fetch(url, {
  ...options,
  body: JSON.stringify({
    ...requestBody,
    stream: true
  })
});

const reader = response.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  
  const chunk = decoder.decode(value);
  // Process SSE events
  processChunk(chunk);
}
```

---

## Token Usage

Monitor token consumption for cost management:

```javascript
// Response includes usage stats
const { usage } = response;
console.log(`Input: ${usage.input_tokens}, Output: ${usage.output_tokens}`);

// Estimate costs
const inputCost = usage.input_tokens * 0.000003;  // $3/million
const outputCost = usage.output_tokens * 0.000015; // $15/million
```

---

## Testing

### Mock API for Development

```javascript
const mockResponse = {
  content: [{
    type: "text",
    text: "Mock response for testing"
  }]
};

// Use in tests
jest.mock('./api', () => ({
  callClaude: jest.fn().mockResolvedValue(mockResponse)
}));
```

### Postman Collection

Import the provided Postman collection for API testing:

```json
{
  "info": {
    "name": "GigWorkSeeker AI API"
  },
  "item": [
    {
      "name": "Send Message",
      "request": {
        "method": "POST",
        "url": "https://api.anthropic.com/v1/messages"
      }
    }
  ]
}
```

---

## Security Best Practices

1. **Never expose API keys in client code** - Use environment variables or backend proxy
2. **Validate user input** - Sanitize before sending to API
3. **Implement rate limiting** - Protect against abuse
4. **Log responsibly** - Don't log sensitive data
5. **Use HTTPS** - Always encrypt in transit
