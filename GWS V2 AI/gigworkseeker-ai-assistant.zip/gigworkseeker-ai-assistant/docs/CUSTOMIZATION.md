# GigWorkSeeker AI Assistant - Customization Guide

## Overview

This guide covers how to customize the AI Assistant's behavior, appearance, and functionality.

---

## System Prompt Customization

The system prompt defines the assistant's knowledge and personality.

### Location

| Platform | File | Variable |
|----------|------|----------|
| Web | `GigWorkSeekerAI.jsx` | `systemPrompt` |
| Android | `AIAssistantFragment.kt` | `systemPrompt` |

### Structure

```javascript
const systemPrompt = `
You are the GigWorkSeeker AI Assistant...

PLATFORM OVERVIEW:
// Describe what the platform does

KEY FEATURES:
// List major features with details

USER TYPES:
// Define user roles

VERIFICATION REQUIREMENTS:
// Explain verification process

PAYMENT OPTIONS:
// List payment methods

YOUR ROLE:
// What the assistant should do

RESPONSE STYLE:
// Communication guidelines

CATEGORIES AVAILABLE:
// All gig categories
`;
```

### Adding New Features

When you add features to GigWorkSeeker, update the system prompt:

```javascript
KEY FEATURES:
- GIG Token: Platform's native cryptocurrency (10 billion supply)
- Smart Contract Escrow: Funds held securely until completion
// Add new features here:
- Voice Chat: Real-time audio communication between users
- AI Recommendations: Personalized gig suggestions based on history
```

### Adjusting Personality

Modify the `RESPONSE STYLE` section:

```javascript
RESPONSE STYLE:
- Be friendly, concise, and helpful
- Use emoji occasionally for warmth 👋
- Match the user's energy level
- Ask clarifying questions when needed
- Celebrate user achievements
```

---

## Suggestion Patterns

Suggestions are context-aware follow-up actions.

### Adding New Patterns

```javascript
// In generateSuggestions function
const generateSuggestions = (userMsg, assistantMsg) => {
  const lowerUser = userMsg.toLowerCase();

  // Existing patterns...

  // Add new pattern
  if (lowerUser.includes('token') || lowerUser.includes('gig token')) {
    return [
      { icon: '💎', text: 'What is the GIG token?' },
      { icon: '📈', text: 'How do I earn tokens?' },
      { icon: '🔒', text: 'Staking rewards explained' },
      { icon: '💱', text: 'How to swap tokens' }
    ];
  }

  // Default suggestions...
};
```

### Kotlin Version

```kotlin
private fun generateSuggestions(userMsg: String, assistantMsg: String): List<Suggestion> {
    val lowerUser = userMsg.lowercase()

    return when {
        // Existing patterns...
        
        // Add new pattern
        lowerUser.contains("token") || lowerUser.contains("gig token") -> listOf(
            Suggestion("💎", "What is the GIG token?"),
            Suggestion("📈", "How do I earn tokens?"),
            Suggestion("🔒", "Staking rewards explained"),
            Suggestion("💱", "How to swap tokens")
        )
        
        // Default...
        else -> defaultSuggestions
    }
}
```

---

## Visual Customization

### Color Palette

#### Web (CSS/JavaScript)

```javascript
const styles = {
  // Primary colors
  SolanaGreen: '#14F195',
  SolanaPurple: '#9945FF',
  
  // Background
  DarkBg: '#0D0D0D',
  DarkCard: '#1A1A1A',
  DarkBorder: '#2A2A2A',
  
  // Text
  TextPrimary: '#FFFFFF',
  TextSecondary: '#AAAAAA',
  TextMuted: '#666666',
};
```

#### Android (Kotlin)

```kotlin
object GWSColors {
    val SolanaGreen = Color(0xFF14F195)
    val SolanaPurple = Color(0xFF9945FF)
    val DarkBg = Color(0xFF0D0D0D)
    val DarkCard = Color(0xFF1A1A1A)
    val DarkBorder = Color(0xFF2A2A2A)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFAAAAAA)
    val TextMuted = Color(0xFF666666)
}
```

### Light Theme

To add light theme support:

```kotlin
// Theme.kt
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00A86B),  // Darker green for contrast
    secondary = Color(0xFF7B2CBF),
    background = Color(0xFFF5F5F5),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color(0xFFFFFFFF),
    onBackground = Color(0xFF1A1A1A),
    onSurface = Color(0xFF1A1A1A)
)

@Composable
fun GigWorkSeekerAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    // ...
}
```

### Typography

#### Web

```css
:root {
  --font-primary: 'Space Grotesk', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}
```

#### Android

```kotlin
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily(Font(R.font.space_grotesk)),
        fontSize = 16.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily(Font(R.font.space_grotesk_bold)),
        fontSize = 22.sp
    )
)
```

---

## Layout Customization

### Message Bubble Styles

```javascript
// Rounded bubbles
const messageBubble = {
  borderRadius: '20px',
  padding: '16px 20px',
};

// Sharp modern style
const messageBubble = {
  borderRadius: '4px',
  padding: '14px 16px',
  borderLeft: '3px solid #14F195',
};
```

### Input Area Variants

```javascript
// Floating input
const inputArea = {
  position: 'fixed',
  bottom: '20px',
  left: '50%',
  transform: 'translateX(-50%)',
  width: '90%',
  maxWidth: '600px',
  borderRadius: '25px',
  boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
};

// Full-width input
const inputArea = {
  width: '100%',
  borderTop: '1px solid rgba(255,255,255,0.1)',
  padding: '16px',
};
```

---

## Feature Toggles

Add feature flags for gradual rollout:

```javascript
const config = {
  features: {
    voiceInput: false,
    richCards: false,
    conversationHistory: false,
    actionExecution: false,
  }
};

// Usage
{config.features.voiceInput && (
  <VoiceInputButton onClick={handleVoice} />
)}
```

---

## Localization

### Adding Languages

```javascript
// i18n/en.json
{
  "placeholder": "Ask me anything about GigWorkSeeker...",
  "online": "Online",
  "poweredBy": "Powered by Claude AI"
}

// i18n/es.json
{
  "placeholder": "Pregúntame lo que quieras sobre GigWorkSeeker...",
  "online": "En línea",
  "poweredBy": "Impulsado por Claude AI"
}
```

### Android Strings

```xml
<!-- values/strings.xml (English) -->
<string name="input_placeholder">Ask me anything...</string>

<!-- values-es/strings.xml (Spanish) -->
<string name="input_placeholder">Pregúntame lo que quieras...</string>
```

---

## Analytics Integration

### Event Tracking

```javascript
// Track message sent
analytics.track('ai_message_sent', {
  messageLength: input.length,
  category: detectCategory(input)
});

// Track suggestion clicked
analytics.track('suggestion_clicked', {
  suggestionText: suggestion.text
});

// Track session duration
analytics.track('ai_session_ended', {
  duration: sessionDuration,
  messageCount: messages.length
});
```

---

## Performance Optimization

### Lazy Loading

```javascript
// Load AI component only when needed
const GigWorkSeekerAI = React.lazy(() => import('./GigWorkSeekerAI'));

function App() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <GigWorkSeekerAI />
    </Suspense>
  );
}
```

### Message Virtualization

For long conversations:

```javascript
import { FixedSizeList } from 'react-window';

<FixedSizeList
  height={containerHeight}
  itemCount={messages.length}
  itemSize={100}
>
  {({ index, style }) => (
    <MessageBubble message={messages[index]} style={style} />
  )}
</FixedSizeList>
```

---

## Extending Functionality

### Adding Voice Input

```javascript
const startVoiceInput = () => {
  const recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    setInput(transcript);
    sendMessage(transcript);
  };
  
  recognition.start();
};
```

### Adding Rich Response Cards

```javascript
// Detect structured data in response
const parseResponse = (text) => {
  const gigPattern = /GIG:\s*(.+)\nLocation:\s*(.+)\nPay:\s*(.+)/;
  const match = text.match(gigPattern);
  
  if (match) {
    return {
      type: 'gig_card',
      data: { title: match[1], location: match[2], pay: match[3] }
    };
  }
  
  return { type: 'text', data: text };
};
```

---

## Testing Customizations

### Unit Tests

```javascript
describe('generateSuggestions', () => {
  it('returns token suggestions for token queries', () => {
    const result = generateSuggestions('tell me about gig token', '');
    expect(result).toContainEqual(
      expect.objectContaining({ text: 'What is the GIG token?' })
    );
  });
});
```

### Visual Regression

Use tools like Chromatic or Percy to catch visual changes:

```javascript
// In Storybook
export const DarkTheme = () => <GigWorkSeekerAI />;
export const LightTheme = () => <ThemeProvider theme="light"><GigWorkSeekerAI /></ThemeProvider>;
```
