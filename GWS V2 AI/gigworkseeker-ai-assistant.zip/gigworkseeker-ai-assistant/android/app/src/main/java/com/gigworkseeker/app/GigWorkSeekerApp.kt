package com.gigworkseeker.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * GigWorkSeeker AI Assistant Application
 * 
 * Main application class with Hilt dependency injection setup.
 */
@HiltAndroidApp
class GigWorkSeekerApp : Application() {
    
    override fun onCreate() {
        super.onCreate()
        // Initialize any app-wide services here
    }
}
