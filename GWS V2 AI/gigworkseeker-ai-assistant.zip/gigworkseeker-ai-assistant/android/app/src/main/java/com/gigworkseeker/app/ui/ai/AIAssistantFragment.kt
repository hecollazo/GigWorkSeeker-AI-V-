package com.gigworkseeker.app.ui.ai

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject

// ============================================================================
// COLOR PALETTE - Solana-inspired design
// ============================================================================
object GWSColors {
    val SolanaGreen = Color(0xFF14F195)
    val SolanaPurple = Color(0xFF9945FF)
    val DarkBg = Color(0xFF0D0D0D)
    val DarkCard = Color(0xFF1A1A1A)
    val DarkBorder = Color(0xFF2A2A2A)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFAAAAAA)
    val TextMuted = Color(0xFF666666)
    
    val GreenGradient = Brush.linearGradient(
        colors = listOf(SolanaGreen, SolanaGreen.copy(alpha = 0.7f))
    )
    val PurpleGreenGradient = Brush.linearGradient(
        colors = listOf(SolanaGreen, SolanaPurple)
    )
}

// ============================================================================
// DATA MODELS
// ============================================================================
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestions: List<Suggestion>? = null
)

enum class MessageRole { USER, ASSISTANT }

data class Suggestion(
    val icon: String,
    val text: String
)

@Serializable
data class ClaudeRequest(
    val model: String = "claude-sonnet-4-20250514",
    val max_tokens: Int = 1000,
    val system: String,
    val messages: List<ClaudeMessage>
)

@Serializable
data class ClaudeMessage(
    val role: String,
    val content: String
)

@Serializable
data class ClaudeResponse(
    val content: List<ContentBlock>
)

@Serializable
data class ContentBlock(
    val type: String,
    val text: String? = null
)

// ============================================================================
// VIEW MODEL
// ============================================================================
@HiltViewModel
class AIAssistantViewModel @Inject constructor() : ViewModel() {
    
    private val json = Json { ignoreUnknownKeys = true }
    
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
    
    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                content = "Hey! I'm your GigWorkSeeker AI assistant. I can help you find gigs, discover top-rated service providers, understand how the platform works, or even help you post a new task. What would you like to do?",
                suggestions = listOf(
                    Suggestion("🔍", "Find gigs near me"),
                    Suggestion("⭐", "Top-rated providers"),
                    Suggestion("📝", "Post a new task"),
                    Suggestion("❓", "How does escrow work?")
                )
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val systemPrompt = """
You are the GigWorkSeeker AI Assistant - a helpful, knowledgeable guide for the GigWorkSeeker platform.

PLATFORM OVERVIEW:
GigWorkSeeker is a blockchain-based gig marketplace built on Solana that connects verified Customers (who post tasks) with Service Providers (who complete them). The platform emphasizes strict identity verification, user-controlled data with zero platform liability, and privacy-first architecture using zero-knowledge proof technology.

KEY FEATURES:
- GIG Token: Platform's native cryptocurrency (10 billion supply) for payments and staking
- Smart Contract Escrow: Funds are held securely until gig completion
- Zero-Knowledge Proof Verification: Users prove identity without exposing personal data
- GPS-Based Matching: Find local gigs and providers
- 5-Star Rating System: With detailed reviews for skill categories
- Dispute Resolution: Community arbitrators (3 randomly selected verified users) resolve conflicts

USER TYPES:
- Customers: Post tasks, fund escrow, approve completed work
- Service Providers: Accept gigs, complete work, receive payment

VERIFICATION REQUIREMENTS:
- Profile photo with face detection
- Government ID verification
- Random face verification when accepting gigs
- All users must be verified to use the platform

PAYMENT OPTIONS:
- Solana (SOL) and GIG tokens
- Google Pay
- Bank transfers
- Credit/Debit cards

YOUR ROLE:
1. Help users find relevant gigs based on their skills, location, and preferences
2. Recommend top-rated service providers for specific tasks
3. Explain platform features (escrow, disputes, verification, payments)
4. Assist with natural language gig posting
5. Provide guidance on pricing, categories, and best practices
6. Answer questions about GIG tokens and blockchain features

RESPONSE STYLE:
- Be friendly, concise, and helpful
- Use bullet points sparingly - prefer conversational prose
- When showing gig listings or provider profiles, format them clearly
- Suggest relevant follow-up actions
- If you don't know something specific, be honest and offer to help in other ways

CATEGORIES AVAILABLE:
Home Services, Delivery, Tech Support, Tutoring, Pet Care, Cleaning, Landscaping, Handyman, Moving, Photography, Event Planning, Personal Training, Cooking/Catering, Auto Services, Creative Services, Virtual Assistance, and more.
""".trimIndent()
    
    fun sendMessage(userMessage: String) {
        if (userMessage.isBlank() || _isLoading.value) return
        
        viewModelScope.launch {
            // Add user message
            val newUserMessage = ChatMessage(
                role = MessageRole.USER,
                content = userMessage
            )
            _messages.value = _messages.value + newUserMessage
            _isLoading.value = true
            
            try {
                val response = callClaudeAPI(userMessage)
                val suggestions = generateSuggestions(userMessage, response)
                
                val assistantMessage = ChatMessage(
                    role = MessageRole.ASSISTANT,
                    content = response,
                    suggestions = suggestions
                )
                _messages.value = _messages.value + assistantMessage
            } catch (e: Exception) {
                val errorMessage = ChatMessage(
                    role = MessageRole.ASSISTANT,
                    content = "I'm having trouble connecting right now. Please try again in a moment.",
                    suggestions = listOf(Suggestion("🔄", "Try again"))
                )
                _messages.value = _messages.value + errorMessage
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    private suspend fun callClaudeAPI(userMessage: String): String {
        val conversationHistory = _messages.value
            .filter { it.suggestions == null || it.role == MessageRole.ASSISTANT }
            .map { ClaudeMessage(
                role = if (it.role == MessageRole.USER) "user" else "assistant",
                content = it.content
            ) }
        
        val request = ClaudeRequest(
            system = systemPrompt,
            messages = conversationHistory + ClaudeMessage("user", userMessage)
        )
        
        val requestBody = json.encodeToString(request)
            .toRequestBody("application/json".toMediaType())
        
        val httpRequest = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("Content-Type", "application/json")
            .addHeader("anthropic-version", "2023-06-01")
            .post(requestBody)
            .build()
        
        val response = httpClient.newCall(httpRequest).execute()
        val responseBody = response.body?.string() ?: throw Exception("Empty response")
        
        val claudeResponse = json.decodeFromString<ClaudeResponse>(responseBody)
        return claudeResponse.content
            .filter { it.type == "text" }
            .mapNotNull { it.text }
            .joinToString("\n")
    }
    
    private fun generateSuggestions(userMsg: String, assistantMsg: String): List<Suggestion> {
        val lowerUser = userMsg.lowercase()
        
        return when {
            lowerUser.contains("gig") || lowerUser.contains("job") || lowerUser.contains("work") -> listOf(
                Suggestion("📍", "Show nearby gigs"),
                Suggestion("💰", "Highest paying gigs"),
                Suggestion("⚡", "Quick gigs under 2 hours")
            )
            lowerUser.contains("provider") || lowerUser.contains("hire") || lowerUser.contains("find someone") -> listOf(
                Suggestion("⭐", "Top rated in my area"),
                Suggestion("✅", "Available right now"),
                Suggestion("💼", "View their portfolio")
            )
            lowerUser.contains("escrow") || lowerUser.contains("payment") || lowerUser.contains("pay") -> listOf(
                Suggestion("🔒", "How is my payment protected?"),
                Suggestion("💳", "Payment methods accepted"),
                Suggestion("⏱️", "When do providers get paid?")
            )
            lowerUser.contains("dispute") || lowerUser.contains("problem") || lowerUser.contains("issue") -> listOf(
                Suggestion("⚖️", "How are disputes resolved?"),
                Suggestion("📋", "What evidence can I submit?"),
                Suggestion("⏰", "How long does resolution take?")
            )
            lowerUser.contains("post") || lowerUser.contains("create") || lowerUser.contains("new task") -> listOf(
                Suggestion("💡", "Tips for good gig posts"),
                Suggestion("💰", "How should I price my gig?"),
                Suggestion("📷", "Should I add photos?")
            )
            else -> listOf(
                Suggestion("🔍", "Search for gigs"),
                Suggestion("👤", "Find a provider"),
                Suggestion("❓", "Ask another question")
            )
        }
    }
}

// ============================================================================
// COMPOSABLES
// ============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIAssistantScreen(viewModel: AIAssistantViewModel) {
    val messages by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    
    // Auto-scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GWSColors.DarkBg)
    ) {
        // Background gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                GWSColors.SolanaGreen.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(size.width * 0.5f, 0f),
                            radius = size.width * 0.8f
                        )
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                GWSColors.SolanaPurple.copy(alpha = 0.06f),
                                Color.Transparent
                            ),
                            center = Offset(size.width, size.height),
                            radius = size.width * 0.6f
                        )
                    )
                }
        )
        
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            AIAssistantHeader()
            
            // Messages
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        onSuggestionClick = { suggestion ->
                            viewModel.sendMessage(suggestion.text)
                        }
                    )
                }
                
                // Typing indicator
                if (isLoading) {
                    item {
                        TypingIndicator()
                    }
                }
            }
            
            // Input area
            InputArea(
                value = inputText,
                onValueChange = { inputText = it },
                onSend = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                isLoading = isLoading,
                focusRequester = focusRequester
            )
        }
    }
}

@Composable
fun AIAssistantHeader() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = GWSColors.DarkBg.copy(alpha = 0.95f),
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Logo icon
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    GWSColors.SolanaGreen.copy(alpha = 0.2f),
                                    GWSColors.SolanaPurple.copy(alpha = 0.2f)
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = GWSColors.SolanaGreen.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = GWSColors.SolanaGreen,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Column {
                    Text(
                        text = "GigWorkSeeker",
                        style = TextStyle(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            brush = GWSColors.PurpleGreenGradient
                        )
                    )
                    Text(
                        text = "AI Assistant",
                        fontSize = 12.sp,
                        color = GWSColors.TextMuted,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            
            // Status badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(GWSColors.SolanaGreen.copy(alpha = 0.1f))
                    .border(
                        width = 1.dp,
                        color = GWSColors.SolanaGreen.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Pulsing dot
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val alpha by infiniteTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = 0.4f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulse"
                )
                
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(GWSColors.SolanaGreen.copy(alpha = alpha))
                )
                
                Text(
                    text = "Online",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GWSColors.SolanaGreen
                )
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage,
    onSuggestionClick: (Suggestion) -> Unit
) {
    val isUser = message.role == MessageRole.USER
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            // AI Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                GWSColors.SolanaGreen.copy(alpha = 0.2f),
                                GWSColors.SolanaGreen.copy(alpha = 0.05f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = GWSColors.SolanaGreen.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.SmartToy,
                    contentDescription = null,
                    tint = GWSColors.SolanaGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
        }
        
        Column(
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) Color.Transparent else GWSColors.DarkCard,
                border = if (isUser) null else androidx.compose.foundation.BorderStroke(
                    1.dp,
                    GWSColors.DarkBorder
                )
            ) {
                Box(
                    modifier = if (isUser) {
                        Modifier.background(GWSColors.GreenGradient)
                    } else {
                        Modifier
                    }
                ) {
                    Text(
                        text = message.content,
                        modifier = Modifier.padding(14.dp),
                        fontSize = 15.sp,
                        color = if (isUser) GWSColors.DarkBg else GWSColors.TextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }
            
            // Suggestions
            if (!isUser && message.suggestions != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    message.suggestions.forEach { suggestion ->
                        SuggestionChip(
                            suggestion = suggestion,
                            onClick = { onSuggestionClick(suggestion) }
                        )
                    }
                }
            }
        }
        
        if (isUser) {
            Spacer(modifier = Modifier.width(12.dp))
            // User Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(GWSColors.PurpleGreenGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = GWSColors.DarkBg,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun SuggestionChip(
    suggestion: Suggestion,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = GWSColors.DarkCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            GWSColors.DarkBorder
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = suggestion.icon, fontSize = 14.sp)
            Text(
                text = suggestion.text,
                fontSize = 13.sp,
                color = GWSColors.TextPrimary
            )
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = GWSColors.TextMuted,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun TypingIndicator() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        // AI Avatar
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            GWSColors.SolanaGreen.copy(alpha = 0.2f),
                            GWSColors.SolanaGreen.copy(alpha = 0.05f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    color = GWSColors.SolanaGreen.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SmartToy,
                contentDescription = null,
                tint = GWSColors.SolanaGreen,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = 4.dp,
                bottomEnd = 16.dp
            ),
            color = GWSColors.DarkCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, GWSColors.DarkBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                repeat(3) { index ->
                    val infiniteTransition = rememberInfiniteTransition(label = "dot$index")
                    val offsetY by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = -6f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(400, delayMillis = index * 150),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "dot$index"
                    )
                    
                    Box(
                        modifier = Modifier
                            .offset(y = offsetY.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(GWSColors.SolanaGreen)
                    )
                }
            }
        }
    }
}

@Composable
fun InputArea(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    isLoading: Boolean,
    focusRequester: FocusRequester
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = GWSColors.DarkBg.copy(alpha = 0.95f),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(GWSColors.DarkCard)
                    .border(
                        width = 1.dp,
                        color = GWSColors.DarkBorder,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    textStyle = TextStyle(
                        fontSize = 15.sp,
                        color = GWSColors.TextPrimary
                    ),
                    singleLine = false,
                    maxLines = 4,
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            if (value.isEmpty()) {
                                Text(
                                    text = "Ask me anything about GigWorkSeeker...",
                                    fontSize = 15.sp,
                                    color = GWSColors.TextMuted
                                )
                            }
                            innerTextField()
                        }
                    }
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                // Send button
                val buttonEnabled = value.isNotBlank() && !isLoading
                
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (buttonEnabled) GWSColors.PurpleGreenGradient
                            else Brush.linearGradient(
                                colors = listOf(
                                    GWSColors.TextMuted.copy(alpha = 0.3f),
                                    GWSColors.TextMuted.copy(alpha = 0.3f)
                                )
                            )
                        )
                        .clickable(enabled = buttonEnabled) { onSend() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = GWSColors.DarkBg,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = GWSColors.DarkBg,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            // Disclaimer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = GWSColors.TextMuted,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Powered by Claude AI • Your data stays private",
                    fontSize = 12.sp,
                    color = GWSColors.TextMuted
                )
            }
        }
    }
}

// ============================================================================
// FRAGMENT
// ============================================================================
@AndroidEntryPoint
class AIAssistantFragment : Fragment() {
    
    private val viewModel: AIAssistantViewModel by viewModels()
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                AIAssistantScreen(viewModel = viewModel)
            }
        }
    }
}
