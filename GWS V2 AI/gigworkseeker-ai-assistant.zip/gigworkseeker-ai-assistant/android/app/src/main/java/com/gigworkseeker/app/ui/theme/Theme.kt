package com.gigworkseeker.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// GigWorkSeeker color palette
object GWSColors {
    val SolanaGreen = Color(0xFF14F195)
    val SolanaPurple = Color(0xFF9945FF)
    val DarkBg = Color(0xFF0D0D0D)
    val DarkCard = Color(0xFF1A1A1A)
    val DarkBorder = Color(0xFF2A2A2A)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFAAAAAA)
    val TextMuted = Color(0xFF666666)
}

private val DarkColorScheme = darkColorScheme(
    primary = GWSColors.SolanaGreen,
    secondary = GWSColors.SolanaPurple,
    tertiary = GWSColors.SolanaGreen,
    background = GWSColors.DarkBg,
    surface = GWSColors.DarkCard,
    onPrimary = GWSColors.DarkBg,
    onSecondary = GWSColors.TextPrimary,
    onTertiary = GWSColors.DarkBg,
    onBackground = GWSColors.TextPrimary,
    onSurface = GWSColors.TextPrimary,
    surfaceVariant = GWSColors.DarkCard,
    onSurfaceVariant = GWSColors.TextSecondary,
    outline = GWSColors.DarkBorder,
    outlineVariant = GWSColors.DarkBorder
)

@Composable
fun GigWorkSeekerAITheme(
    darkTheme: Boolean = true, // Always use dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = GWSColors.DarkBg.toArgb()
            window.navigationBarColor = GWSColors.DarkBg.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
