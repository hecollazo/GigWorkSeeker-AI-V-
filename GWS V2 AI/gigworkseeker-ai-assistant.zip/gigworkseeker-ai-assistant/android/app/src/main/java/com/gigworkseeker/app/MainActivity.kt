package com.gigworkseeker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.gigworkseeker.app.ui.ai.AIAssistantScreen
import com.gigworkseeker.app.ui.ai.AIAssistantViewModel
import com.gigworkseeker.app.ui.theme.GigWorkSeekerAITheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Main Activity for GigWorkSeeker AI Assistant
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            GigWorkSeekerAITheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: AIAssistantViewModel = hiltViewModel()
                    AIAssistantScreen(viewModel = viewModel)
                }
            }
        }
    }
}
