import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, MapPin, Clock, DollarSign, Star, Briefcase, User, Search, Zap, ChevronDown, Loader2, Bot, ArrowRight } from 'lucide-react';

// GigWorkSeeker AI Assistant - Conversational interface powered by Claude
export default function GigWorkSeekerAI() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hey! I'm your GigWorkSeeker AI assistant. I can help you find gigs, discover top-rated service providers, understand how the platform works, or even help you post a new task. What would you like to do?",
      suggestions: [
        { icon: '🔍', text: 'Find gigs near me' },
        { icon: '⭐', text: 'Top-rated providers' },
        { icon: '📝', text: 'Post a new task' },
        { icon: '❓', text: 'How does escrow work?' }
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input on load
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // System prompt for Claude with GigWorkSeeker context
  const systemPrompt = `You are the GigWorkSeeker AI Assistant - a helpful, knowledgeable guide for the GigWorkSeeker platform.

PLATFORM OVERVIEW:
GigWorkSeeker is a blockchain-based gig marketplace built on Solana that connects verified Customers (who post tasks) with Service Providers (who complete them). The platform emphasizes strict identity verification, user-controlled data with zero platform liability, and privacy-first architecture using zero-knowledge proof technology.

KEY FEATURES:
- GIG Token: Platform's native cryptocurrency (10 billion supply) for payments and staking
- Smart Contract Escrow: Funds are held securely until gig completion
- Zero-Knowledge Proof Verification: Users prove identity without exposing personal data
- GPS-Based Matching: Find local gigs and providers
- 5-Star Rating System: With detailed reviews for skill categories
- Dispute Resolution: Community arbitrators (3 randomly selected verified users) resolve conflicts

USER TYPES:
- Customers: Post tasks, fund escrow, approve completed work
- Service Providers: Accept gigs, complete work, receive payment

VERIFICATION REQUIREMENTS:
- Profile photo with face detection
- Government ID verification
- Random face verification when accepting gigs
- All users must be verified to use the platform

PAYMENT OPTIONS:
- Solana (SOL) and GIG tokens
- Google Pay
- Bank transfers
- Credit/Debit cards

YOUR ROLE:
1. Help users find relevant gigs based on their skills, location, and preferences
2. Recommend top-rated service providers for specific tasks
3. Explain platform features (escrow, disputes, verification, payments)
4. Assist with natural language gig posting
5. Provide guidance on pricing, categories, and best practices
6. Answer questions about GIG tokens and blockchain features

RESPONSE STYLE:
- Be friendly, concise, and helpful
- Use bullet points sparingly - prefer conversational prose
- When showing gig listings or provider profiles, format them clearly
- Suggest relevant follow-up actions
- If you don't know something specific, be honest and offer to help in other ways

CATEGORIES AVAILABLE:
Home Services, Delivery, Tech Support, Tutoring, Pet Care, Cleaning, Landscaping, Handyman, Moving, Photography, Event Planning, Personal Training, Cooking/Catering, Auto Services, Creative Services, Virtual Assistance, and more.`;

  // Send message to Claude API
  const sendMessage = async (userMessage) => {
    if (!userMessage.trim()) return;

    const newUserMessage = { role: 'user', content: userMessage };
    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);
    setIsTyping(true);

    try {
      // Build conversation history for context
      const conversationHistory = messages
        .filter(m => !m.suggestions) // Exclude suggestion metadata
        .map(m => ({
          role: m.role,
          content: m.content
        }));

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: systemPrompt,
          messages: [...conversationHistory, { role: 'user', content: userMessage }]
        })
      });

      const data = await response.json();
      const assistantMessage = data.content
        .filter(block => block.type === 'text')
        .map(block => block.text)
        .join('\n');

      // Generate contextual suggestions based on the conversation
      const suggestions = generateSuggestions(userMessage, assistantMessage);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: assistantMessage,
        suggestions
      }]);
    } catch (error) {
      console.error('Error calling Claude API:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I'm having trouble connecting right now. Please try again in a moment.",
        suggestions: [{ icon: '🔄', text: 'Try again' }]
      }]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  // Generate contextual follow-up suggestions
  const generateSuggestions = (userMsg, assistantMsg) => {
    const lowerUser = userMsg.toLowerCase();
    const lowerAssistant = assistantMsg.toLowerCase();

    if (lowerUser.includes('gig') || lowerUser.includes('job') || lowerUser.includes('work')) {
      return [
        { icon: '📍', text: 'Show nearby gigs' },
        { icon: '💰', text: 'Highest paying gigs' },
        { icon: '⚡', text: 'Quick gigs under 2 hours' }
      ];
    }
    if (lowerUser.includes('provider') || lowerUser.includes('hire') || lowerUser.includes('find someone')) {
      return [
        { icon: '⭐', text: 'Top rated in my area' },
        { icon: '✅', text: 'Available right now' },
        { icon: '💼', text: 'View their portfolio' }
      ];
    }
    if (lowerUser.includes('escrow') || lowerUser.includes('payment') || lowerUser.includes('pay')) {
      return [
        { icon: '🔒', text: 'How is my payment protected?' },
        { icon: '💳', text: 'Payment methods accepted' },
        { icon: '⏱️', text: 'When do providers get paid?' }
      ];
    }
    if (lowerUser.includes('dispute') || lowerUser.includes('problem') || lowerUser.includes('issue')) {
      return [
        { icon: '⚖️', text: 'How are disputes resolved?' },
        { icon: '📋', text: 'What evidence can I submit?' },
        { icon: '⏰', text: 'How long does resolution take?' }
      ];
    }
    if (lowerUser.includes('post') || lowerUser.includes('create') || lowerUser.includes('new task')) {
      return [
        { icon: '💡', text: 'Tips for good gig posts' },
        { icon: '💰', text: 'How should I price my gig?' },
        { icon: '📷', text: 'Should I add photos?' }
      ];
    }
    // Default suggestions
    return [
      { icon: '🔍', text: 'Search for gigs' },
      { icon: '👤', text: 'Find a provider' },
      { icon: '❓', text: 'Ask another question' }
    ];
  };

  const handleSuggestionClick = (suggestion) => {
    sendMessage(suggestion.text);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <div style={styles.container}>
      {/* Animated background */}
      <div style={styles.backgroundGradient} />
      <div style={styles.gridOverlay} />
      
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerContent}>
          <div style={styles.logoSection}>
            <div style={styles.logoIcon}>
              <Zap size={24} color="#14F195" />
            </div>
            <div>
              <h1 style={styles.logoText}>GigWorkSeeker</h1>
              <span style={styles.aiLabel}>AI Assistant</span>
            </div>
          </div>
          <div style={styles.statusBadge}>
            <span style={styles.statusDot} />
            <span style={styles.statusText}>Online</span>
          </div>
        </div>
      </header>

      {/* Chat Container */}
      <main style={styles.chatContainer}>
        <div style={styles.messagesWrapper}>
          {messages.map((message, index) => (
            <div
              key={index}
              style={{
                ...styles.messageRow,
                justifyContent: message.role === 'user' ? 'flex-end' : 'flex-start'
              }}
            >
              {message.role === 'assistant' && (
                <div style={styles.avatarContainer}>
                  <Bot size={20} color="#14F195" />
                </div>
              )}
              <div
                style={{
                  ...styles.messageBubble,
                  ...(message.role === 'user' ? styles.userBubble : styles.assistantBubble)
                }}
              >
                <p style={styles.messageText}>{message.content}</p>
                
                {/* Suggestion chips */}
                {message.suggestions && message.role === 'assistant' && (
                  <div style={styles.suggestionsContainer}>
                    {message.suggestions.map((suggestion, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSuggestionClick(suggestion)}
                        style={styles.suggestionChip}
                        onMouseEnter={(e) => {
                          e.target.style.background = 'rgba(20, 241, 149, 0.15)';
                          e.target.style.borderColor = '#14F195';
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.background = 'rgba(255, 255, 255, 0.05)';
                          e.target.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                        }}
                      >
                        <span style={styles.suggestionIcon}>{suggestion.icon}</span>
                        <span>{suggestion.text}</span>
                        <ArrowRight size={14} style={{ opacity: 0.5 }} />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {message.role === 'user' && (
                <div style={styles.userAvatarContainer}>
                  <User size={18} color="#0D0D0D" />
                </div>
              )}
            </div>
          ))}
          
          {/* Typing indicator */}
          {isTyping && (
            <div style={{ ...styles.messageRow, justifyContent: 'flex-start' }}>
              <div style={styles.avatarContainer}>
                <Bot size={20} color="#14F195" />
              </div>
              <div style={{ ...styles.messageBubble, ...styles.assistantBubble }}>
                <div style={styles.typingIndicator}>
                  <span style={{ ...styles.typingDot, animationDelay: '0ms' }} />
                  <span style={{ ...styles.typingDot, animationDelay: '150ms' }} />
                  <span style={{ ...styles.typingDot, animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer style={styles.inputArea}>
        <form onSubmit={handleSubmit} style={styles.inputForm}>
          <div style={styles.inputWrapper}>
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about GigWorkSeeker..."
              style={styles.input}
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              style={{
                ...styles.sendButton,
                opacity: isLoading || !input.trim() ? 0.5 : 1,
                cursor: isLoading || !input.trim() ? 'not-allowed' : 'pointer'
              }}
            >
              {isLoading ? (
                <Loader2 size={20} style={{ animation: 'spin 1s linear infinite' }} />
              ) : (
                <Send size={20} />
              )}
            </button>
          </div>
          <p style={styles.disclaimer}>
            <Sparkles size={12} style={{ marginRight: 4 }} />
            Powered by Claude AI • Your data stays private
          </p>
        </form>
      </footer>

      {/* Global styles for animations */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
        
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        
        html, body, #root {
          height: 100%;
          width: 100%;
          overflow: hidden;
        }
        
        ::-webkit-scrollbar {
          width: 6px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
        }
        
        ::-webkit-scrollbar-thumb {
          background: rgba(20, 241, 149, 0.3);
          border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(20, 241, 149, 0.5);
        }
      `}</style>
    </div>
  );
}

// Styles object
const styles = {
  container: {
    fontFamily: "'Space Grotesk', sans-serif",
    height: '100vh',
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    background: '#0D0D0D',
    color: '#FFFFFF',
    position: 'relative',
    overflow: 'hidden'
  },
  backgroundGradient: {
    position: 'absolute',
    inset: 0,
    background: 'radial-gradient(ellipse at top, rgba(20, 241, 149, 0.08) 0%, transparent 50%), radial-gradient(ellipse at bottom right, rgba(153, 69, 255, 0.06) 0%, transparent 50%)',
    pointerEvents: 'none'
  },
  gridOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundImage: `linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)`,
    backgroundSize: '50px 50px',
    pointerEvents: 'none'
  },
  header: {
    borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
    padding: '16px 24px',
    background: 'rgba(13, 13, 13, 0.8)',
    backdropFilter: 'blur(20px)',
    position: 'relative',
    zIndex: 10
  },
  headerContent: {
    maxWidth: '900px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px'
  },
  logoIcon: {
    width: '44px',
    height: '44px',
    borderRadius: '12px',
    background: 'linear-gradient(135deg, rgba(20, 241, 149, 0.2) 0%, rgba(153, 69, 255, 0.2) 100%)',
    border: '1px solid rgba(20, 241, 149, 0.3)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  logoText: {
    fontSize: '20px',
    fontWeight: '700',
    background: 'linear-gradient(135deg, #14F195 0%, #9945FF 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    backgroundClip: 'text',
    margin: 0
  },
  aiLabel: {
    fontSize: '12px',
    color: 'rgba(255, 255, 255, 0.5)',
    fontWeight: '500',
    letterSpacing: '0.5px'
  },
  statusBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 14px',
    background: 'rgba(20, 241, 149, 0.1)',
    borderRadius: '20px',
    border: '1px solid rgba(20, 241, 149, 0.2)'
  },
  statusDot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    background: '#14F195',
    animation: 'pulse 2s ease-in-out infinite'
  },
  statusText: {
    fontSize: '13px',
    fontWeight: '500',
    color: '#14F195'
  },
  chatContainer: {
    flex: 1,
    overflow: 'hidden',
    position: 'relative',
    zIndex: 1
  },
  messagesWrapper: {
    height: '100%',
    overflowY: 'auto',
    padding: '24px',
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    maxWidth: '900px',
    margin: '0 auto'
  },
  messageRow: {
    display: 'flex',
    gap: '12px',
    alignItems: 'flex-start'
  },
  avatarContainer: {
    width: '36px',
    height: '36px',
    borderRadius: '10px',
    background: 'linear-gradient(135deg, rgba(20, 241, 149, 0.2) 0%, rgba(20, 241, 149, 0.05) 100%)',
    border: '1px solid rgba(20, 241, 149, 0.3)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0
  },
  userAvatarContainer: {
    width: '36px',
    height: '36px',
    borderRadius: '10px',
    background: 'linear-gradient(135deg, #14F195 0%, #9945FF 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0
  },
  messageBubble: {
    maxWidth: '75%',
    padding: '14px 18px',
    borderRadius: '16px',
    lineHeight: '1.6'
  },
  userBubble: {
    background: 'linear-gradient(135deg, rgba(20, 241, 149, 0.9) 0%, rgba(20, 241, 149, 0.7) 100%)',
    color: '#0D0D0D',
    borderBottomRightRadius: '4px'
  },
  assistantBubble: {
    background: 'rgba(255, 255, 255, 0.06)',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    borderBottomLeftRadius: '4px'
  },
  messageText: {
    margin: 0,
    fontSize: '15px',
    whiteSpace: 'pre-wrap'
  },
  suggestionsContainer: {
    marginTop: '14px',
    display: 'flex',
    flexWrap: 'wrap',
    gap: '8px'
  },
  suggestionChip: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '10px 14px',
    background: 'rgba(255, 255, 255, 0.05)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '10px',
    color: '#FFFFFF',
    fontSize: '13px',
    fontFamily: "'Space Grotesk', sans-serif",
    cursor: 'pointer',
    transition: 'all 0.2s ease'
  },
  suggestionIcon: {
    fontSize: '14px'
  },
  typingIndicator: {
    display: 'flex',
    gap: '6px',
    padding: '4px 0'
  },
  typingDot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    background: '#14F195',
    animation: 'bounce 1.4s ease-in-out infinite'
  },
  inputArea: {
    borderTop: '1px solid rgba(255, 255, 255, 0.08)',
    padding: '20px 24px',
    background: 'rgba(13, 13, 13, 0.9)',
    backdropFilter: 'blur(20px)',
    position: 'relative',
    zIndex: 10
  },
  inputForm: {
    maxWidth: '900px',
    margin: '0 auto'
  },
  inputWrapper: {
    display: 'flex',
    gap: '12px',
    background: 'rgba(255, 255, 255, 0.05)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '14px',
    padding: '6px 6px 6px 18px',
    alignItems: 'center',
    transition: 'all 0.2s ease'
  },
  input: {
    flex: 1,
    background: 'transparent',
    border: 'none',
    outline: 'none',
    color: '#FFFFFF',
    fontSize: '15px',
    fontFamily: "'Space Grotesk', sans-serif",
    padding: '10px 0'
  },
  sendButton: {
    width: '44px',
    height: '44px',
    borderRadius: '10px',
    background: 'linear-gradient(135deg, #14F195 0%, #9945FF 100%)',
    border: 'none',
    color: '#0D0D0D',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.2s ease',
    flexShrink: 0
  },
  disclaimer: {
    marginTop: '12px',
    fontSize: '12px',
    color: 'rgba(255, 255, 255, 0.4)',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
};
