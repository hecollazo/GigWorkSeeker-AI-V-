import React from 'react';
import GigWorkSeekerAI from './components/GigWorkSeekerAI';

function App() {
  return <GigWorkSeekerAI />;
}

export default App;
