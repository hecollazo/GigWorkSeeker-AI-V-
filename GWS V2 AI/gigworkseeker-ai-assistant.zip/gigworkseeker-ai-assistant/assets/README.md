# Assets Directory

Place the following assets in this directory:

- `ai-assistant-banner.png` - Banner image for README (1200x630px recommended)
- `logo.svg` - GigWorkSeeker logo
- `favicon.svg` - Favicon for web
- `og-image.png` - Open Graph image for social sharing
- `apple-touch-icon.png` - iOS home screen icon (180x180px)

## Design Guidelines

- Use the Solana color palette:
  - Primary Green: #14F195
  - Secondary Purple: #9945FF
  - Dark Background: #0D0D0D
  
- Typography: Space Grotesk for headings, system fonts for body

- Keep assets optimized for web (compress PNGs, use SVG where possible)
